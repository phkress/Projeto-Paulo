Boa noite Paulo Marinho.

Segue em junto com esse documento o PDF referende a materia com o projeto, ainda esta faltando o PPT, o codigo do projeto esta dentro da pasta client.

Professor o mock de dados, que foi dado pelo professor Erick esta com problemas, eu estava refazendo porem n�o tive tempo ainda de finalizar tudo, ate o momento so tem o  a categoria "Praia" para teste funcionando. Como combinado irei lhe mandar as outras categorias antes do final do praso para voc� testar o trabalho 100%. Pois as outras acabam fazendo tanta requisi��o sem resposta que trava o navegador, e incrementa muito erro no console.
Segue tambem o prototipo no tamanho real caso o que esteja no pdf esta ruim para leitura.


===============Como rodar Projeto====================
1� Para rodar o Projeto por favor baixe esses arquivos e extraia emuma pasta

https://github.com/e-menezes/NG6-starter/tree/at-projeto-bloco

2�Na pasta onde extraiu os arquivos abre um promp e rode o comando npm insall

3� Subtitua a pasta Client pela que esta nesse zip

4� De o comando npm start

5� Abra navegador no endere�o localhost:3000
----------------------------------------------------