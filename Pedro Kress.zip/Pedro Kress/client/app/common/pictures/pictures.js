import angular from 'angular';
import picturesComponent from './pictures.component';

let picturesModule = angular.module('pictures', [

])

.component('pictures', picturesComponent)
  
.name;

export default picturesModule;
