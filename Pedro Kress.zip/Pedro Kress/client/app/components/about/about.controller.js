class AboutController {
  constructor() {
    this.titulo = 'Sobre Rio de Janeiro';
  }
}

export default AboutController;
