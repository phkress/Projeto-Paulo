let data = [
        { id: 1, nome:'Restaurantes',       titulo:'teste', value:'restaurantes',       url:'https://s3-media4.fl.yelpcdn.com/bphoto/yuVzBdpyZhwbC1zENVGhsw/ls.jpg'},
        { id: 2, nome:'Praias',             titulo:'teste', value:'praias',             url:'http://guiaavare.com/public/Cache/4/6/3/0/6/46306de0808900ef9d6dd8f1393bc0035f75df98.jpg'},
        { id: 3, nome:'Jogos Olimpicos',    titulo:'teste', value:'jogos-olimpicos',    url:'http://visit.rio/wp-content/uploads/2016/07/parquemadureira_500-250x250.jpg'},
        { id: 4, nome:'Pontos Turisticos',  titulo:'teste', value:'pontos-turisticos',  url:'https://static.wixstatic.com/media/634855_cfd746aaec55079f3430d23cb4a8b26e.jpg/v1/fill/w_250,h_250,q_85,usm_0.66_1.00_0.01/634855_cfd746aaec55079f3430d23cb4a8b26e.jpg'},
        { id: 5, nome:'Postos Saude',       titulo:'teste', value:'postos-saude',       url:'http://planodesaudesulamericariodejaneiro.info/blog/wp-content/uploads/2017/07/SulAmerica-no-rio-de-janeiro-1400x934-250x250.jpg'},
        { id: 6, nome:'Hoteis',             titulo:'teste', value:'hoteis',             url:'http://www.quetalviajar.com/images/hospedagem/guanabara-palace-hotel-03.jpg'},
        { id: 7, nome:'Escolas',  			titulo:'teste', value:'escolas',            url:'https://s3-media4.fl.yelpcdn.com/bphoto/G38wHfTRBj9Z8ShFWXHzMA/ls.jpg'},
        { id: 8, nome:'Banheiros',          titulo:'teste', value:'banheiros',          url:'http://www.rodoviaria-poa.com.br/mobile/img/banh.png'},
        { id: 9, nome:'Bombeiros',          titulo:'teste', value:'bombeiros',          url:'https://s3-media2.fl.yelpcdn.com/bphoto/4poEqoQgouPzVl4RkNa6WA/ls.jpg'},
        { id: 10, nome:'Delegacias',        titulo:'teste', value:'delegacias',         url:'https://s3-media1.fl.yelpcdn.com/bphoto/7ipOqIBLcPtjI7m2SbBO5g/ls.jpg'},
    ];

export default data;
