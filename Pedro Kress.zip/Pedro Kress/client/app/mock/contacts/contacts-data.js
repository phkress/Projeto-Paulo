let data = [{ //esses contacts estão mockados direto no serviço, não usam o angular-mocks ainda
  "id":1,
  "name": "Mcneil Payne",
  "phone": "+55 (832) 409-2318"
}, {
  "id":2,
  "name": "Mitzi Patterson",
  "phone": "+55 (820) 413-2975"
}, {
  "id":3,
  "name": "Blair Jordan",
  "phone": "+55 (944) 483-3534"
}, {
  "id":4,
  "name": "Walton Fulton",
  "phone": "+55 (986) 582-2748"
}, {
  "id":5,
  "name": "Black Evans",
  "phone": "+55 (886) 492-3379"
}, {
  "id":6,
  "name": "Hurst Banks",
  "phone": "+55 (843) 558-3725"
}];

export default data;
