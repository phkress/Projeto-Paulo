let data = [

{
"id":"1",
"name":"Praça Amambaí 13 Engenho de Dentr",
"description":{
	"short_text":"Praça Amambaí 13 Engenho de Dentr",
	"text":"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
	},
"contactData":"",
"characteristics":{
	"price":"$$",
	"lgbt": ""
	},
"geoResult":{
	"point":{
		"lat":"-22.903152",
		"lng":"-43.294641"
		},
	"neighbourhood":" Engenho de Dentro",
	"address":"Praça Amambaí"
	},
"img":{
	"url":"https://www.greenme.com.br/images/viver/saude-bem-estar/banheiro-publico.jpg",
	"alt":"Praça Amambaí 13 Engenho de Dentr",
	"title":"Praça Amambaí 13 Engenho de Dentr",
	}
},

{
"id":"2",
"name":"Praça Ipupiara - Vicente de Carvalho",
"description":{
	"short_text":"Praça Ipupiara - Vicente de Carvalho",
	"text":"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
	},
"contactData":"",
"characteristics":{
	"price":"$$",
	"lgbt": ""
	},
"geoResult":{
	"point":{
		"lat":"-22.852716",
		"lng":"-43.324794"
		},
	"neighbourhood":" Irajá",
	"address":"PPraça Ipupiara "
	},
"img":{
	"url":"http://2.bp.blogspot.com/-m1RTluto2kc/UnHESziUMkI/AAAAAAAADGg/d_ykmQ-AvAQ/s1600/proj_banh_big.jpg",
	"alt":"Praça Ipupiara - Vicente de Carvalho",
	"title":"Praça Ipupiara - Vicente de Carvalho",
	}
},

]


export default data;