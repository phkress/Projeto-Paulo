let data = [

{
"id":"1",
"name":"DRF - Delegacia de Roubos e Furtos",
"description":{
	"short_text":"Delegacia",
	"text":"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
	},
"contactData":"",
"characteristics":{
	"price":"$$",
	"lgbt": ""
	},
"geoResult":{
	"point":{
		"lat":"-22.896893",
		"lng":"-43.181976"
		},
	"neighbourhood":"Maria da Graça",
	"address":"Av. Dom Hélder Câmara, 2066"
	},
"img":{
	"url":"http://circuitomt.com.br/circuitomt01/2014/2015/Junho/03-06-2015/derf.jpg",
	"alt":"DRF - Delegacia de Roubos e Furtos",
	"title":"DRF - Delegacia de Roubos e Furtos",
	}
},
{
"id":"2",
"name":"DRF - Delegacia de Roubos e Furtos",
"description":{
	"short_text":"Delegacia",
	"text":"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
	},
"contactData":"",
"characteristics":{
	"price":"$$",
	"lgbt": ""
	},
"geoResult":{
	"point":{
		"lat":"-22.896893",
		"lng":"-43.181976"
		},
	"neighbourhood":"Maria da Graça",
	"address":"Av. Dom Hélder Câmara, 2066"
	},
"img":{
	"url":"http://circuitomt.com.br/circuitomt01/2014/2015/Junho/03-06-2015/derf.jpg",
	"alt":"DRF - Delegacia de Roubos e Furtos",
	"title":"DRF - Delegacia de Roubos e Furtos",
	}
},
{
"id":"3",
"name":"DRF - Delegacia de Roubos e Furtos",
"description":{
	"short_text":"Delegacia",
	"text":"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
	},
"contactData":"",
"characteristics":{
	"price":"$$",
	"lgbt": ""
	},
"geoResult":{
	"point":{
		"lat":"-22.896893",
		"lng":"-43.181976"
		},
	"neighbourhood":"Maria da Graça",
	"address":"Av. Dom Hélder Câmara, 2066"
	},
"img":{
	"url":"http://circuitomt.com.br/circuitomt01/2014/2015/Junho/03-06-2015/derf.jpg",
	"alt":"DRF - Delegacia de Roubos e Furtos",
	"title":"DRF - Delegacia de Roubos e Furtos",
	}
},
{
"id":"4",
"name":"DRF - Delegacia de Roubos e Furtos",
"description":{
	"short_text":"Delegacia",
	"text":"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
	},
"contactData":"",
"characteristics":{
	"price":"$$",
	"lgbt": ""
	},
"geoResult":{
	"point":{
		"lat":"-22.896893",
		"lng":"-43.181976"
		},
	"neighbourhood":"Maria da Graça",
	"address":"Av. Dom Hélder Câmara, 2066"
	},
"img":{
	"url":"http://circuitomt.com.br/circuitomt01/2014/2015/Junho/03-06-2015/derf.jpg",
	"alt":"DRF - Delegacia de Roubos e Furtos",
	"title":"DRF - Delegacia de Roubos e Furtos",
	}
},
{
"id":"5",
"name":"DRF - Delegacia de Roubos e Furtos",
"description":{
	"short_text":"Delegacia",
	"text":"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
	},
"contactData":"",
"characteristics":{
	"price":"$$",
	"lgbt": ""
	},
"geoResult":{
	"point":{
		"lat":"-22.896893",
		"lng":"-43.181976"
		},
	"neighbourhood":"Maria da Graça",
	"address":"Av. Dom Hélder Câmara, 2066"
	},
"img":{
	"url":"http://circuitomt.com.br/circuitomt01/2014/2015/Junho/03-06-2015/derf.jpg",
	"alt":"DRF - Delegacia de Roubos e Furtos",
	"title":"DRF - Delegacia de Roubos e Furtos",
	}
},
{
"id":"6",
"name":"DRF - Delegacia de Roubos e Furtos",
"description":{
	"short_text":"Delegacia",
	"text":"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
	},
"contactData":"",
"characteristics":{
	"price":"$$",
	"lgbt": ""
	},
"geoResult":{
	"point":{
		"lat":"-22.896893",
		"lng":"-43.181976"
		},
	"neighbourhood":"Maria da Graça",
	"address":"Av. Dom Hélder Câmara, 2066"
	},
"img":{
	"url":"http://circuitomt.com.br/circuitomt01/2014/2015/Junho/03-06-2015/derf.jpg",
	"alt":"DRF - Delegacia de Roubos e Furtos",
	"title":"DRF - Delegacia de Roubos e Furtos",
	}
},


];

export default data;
