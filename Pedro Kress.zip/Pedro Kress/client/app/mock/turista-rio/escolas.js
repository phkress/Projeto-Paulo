let data = [

{
"id":"1",
"name":"C. C. Professor Walter Carlos de Magalhães Fraenkel",
"description":{
	"short_text":"O Teatro dos Quatro 35 um dos quatro teatros do Shopping da Ga5vea, inaugurado em 1978.Confira a programaxef;fao:",
	"text":"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
	},
"contactData":"",
"characteristics":{
	"price":"$$",
	"lgbt": ""
	},
"geoResult":{
	"point":{
		"lat":"-22.8784",
		"lng":"-43.2241"
		},
	"neighbourhood":"R. Carlos Seidl, 1141",
	"address":"Caju"
	},
"img":{
	"url":"http://www.pragmatismopolitico.com.br/wp-content/uploads/2016/07/escola-e1469804511781.jpg",
	"alt":"C. C. Professor Walter Carlos de Magalhães Fraenkel",
	"title":"C. C. Professor Walter Carlos de Magalhães Fraenkel",
	}
},

{
"id":"2",
"name":"C.C. Casa de São Roque",
"description":{
	"short_text":"O Teatro dos Quatro 35 um dos quatro teatros do Shopping da Ga5vea, inaugurado em 1978.Confira a programaxef;fao:",
	"text":"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
	},
"contactData":"",
"characteristics":{
	"price":"$$",
	"lgbt": ""
	},
"geoResult":{
	"point":{
		"lat":"-22.8971",
		"lng":"-43.2805"
		},
	"neighbourhood":"s/n",
	"address":"s/n"
	},
"img":{
	"url":"https://www.nexojornal.com.br/incoming/imagens/Sala_de_aula_itapevi/BINARY/Sala_de_aula_itapevi",
	"alt":"C. C. Professor Walter Carlos de Magalhães Fraenkel",
	"title":"C. C. Professor Walter Carlos de Magalhães Fraenkel",
	}
},

{
"id":"3",
"name":"C. C. Professor Walter Carlos de Magalhães Fraenkel",
"description":{
	"short_text":"O Teatro dos Quatro 35 um dos quatro teatros do Shopping da Ga5vea, inaugurado em 1978.Confira a programaxef;fao:",
	"text":"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
	},
"contactData":"",
"characteristics":{
	"price":"$$",
	"lgbt": ""
	},
"geoResult":{
	"point":{
		"lat":"--22.8784",
		"lng":"-43.2241"
		},
	"neighbourhood":"R. Carlos Seidl, 1141",
	"address":"Caju"
	},
"img":{
	"url":"http://www.pragmatismopolitico.com.br/wp-content/uploads/2016/07/escola-e1469804511781.jpg",
	"alt":"C. C. Professor Walter Carlos de Magalhães Fraenkel",
	"title":"C. C. Professor Walter Carlos de Magalhães Fraenkel",
	}
},

{
"id":"4",
"name":"C.C. Casa de São Roque",
"description":{
	"short_text":"O Teatro dos Quatro 35 um dos quatro teatros do Shopping da Ga5vea, inaugurado em 1978.Confira a programaxef;fao:",
	"text":"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
	},
"contactData":"",
"characteristics":{
	"price":"$$",
	"lgbt": ""
	},
"geoResult":{
	"point":{
		"lat":"-22.8971",
		"lng":"-43.2805"
		},
	"neighbourhood":"s/n",
	"address":"s/n"
	},
"img":{
	"url":"https://www.nexojornal.com.br/incoming/imagens/Sala_de_aula_itapevi/BINARY/Sala_de_aula_itapevi",
	"alt":"C. C. Professor Walter Carlos de Magalhães Fraenkel",
	"title":"C. C. Professor Walter Carlos de Magalhães Fraenkel",
	}
},

{
"id":"5",
"name":"C. C. Professor Walter Carlos de Magalhães Fraenkel",
"description":{
	"short_text":"O Teatro dos Quatro 35 um dos quatro teatros do Shopping da Ga5vea, inaugurado em 1978.Confira a programaxef;fao:",
	"text":"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
	},
"contactData":"",
"characteristics":{
	"price":"$$",
	"lgbt": ""
	},
"geoResult":{
	"point":{
		"lat":"--22.8784",
		"lng":"-43.2241"
		},
	"neighbourhood":"R. Carlos Seidl, 1141",
	"address":"Caju"
	},
"img":{
	"url":"http://www.pragmatismopolitico.com.br/wp-content/uploads/2016/07/escola-e1469804511781.jpg",
	"alt":"C. C. Professor Walter Carlos de Magalhães Fraenkel",
	"title":"C. C. Professor Walter Carlos de Magalhães Fraenkel",
	}
},

{
"id":"6",
"name":"C.C. Casa de São Roque",
"description":{
	"short_text":"O Teatro dos Quatro 35 um dos quatro teatros do Shopping da Ga5vea, inaugurado em 1978.Confira a programaxef;fao:",
	"text":"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
	},
"contactData":"",
"characteristics":{
	"price":"$$",
	"lgbt": ""
	},
"geoResult":{
	"point":{
		"lat":"-22.8971",
		"lng":"-43.2805"
		},
	"neighbourhood":"s/n",
	"address":"s/n"
	},
"img":{
	"url":"https://www.nexojornal.com.br/incoming/imagens/Sala_de_aula_itapevi/BINARY/Sala_de_aula_itapevi",
	"alt":"C. C. Professor Walter Carlos de Magalhães Fraenkel",
	"title":"C. C. Professor Walter Carlos de Magalhães Fraenkel",
	}
},

{
"id":"7",
"name":"C. C. Professor Walter Carlos de Magalhães Fraenkel",
"description":{
	"short_text":"O Teatro dos Quatro 35 um dos quatro teatros do Shopping da Ga5vea, inaugurado em 1978.Confira a programaxef;fao:",
	"text":"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
	},
"contactData":"",
"characteristics":{
	"price":"$$",
	"lgbt": ""
	},
"geoResult":{
	"point":{
		"lat":"--22.8784",
		"lng":"-43.2241"
		},
	"neighbourhood":"R. Carlos Seidl, 1141",
	"address":"Caju"
	},
"img":{
	"url":"http://www.pragmatismopolitico.com.br/wp-content/uploads/2016/07/escola-e1469804511781.jpg",
	"alt":"C. C. Professor Walter Carlos de Magalhães Fraenkel",
	"title":"C. C. Professor Walter Carlos de Magalhães Fraenkel",
	}
},

{
"id":"8",
"name":"C.C. Casa de São Roque",
"description":{
	"short_text":"O Teatro dos Quatro 35 um dos quatro teatros do Shopping da Ga5vea, inaugurado em 1978.Confira a programaxef;fao:",
	"text":"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
	},
"contactData":"",
"characteristics":{
	"price":"$$",
	"lgbt": ""
	},
"geoResult":{
	"point":{
		"lat":"-22.8971",
		"lng":"-43.2805"
		},
	"neighbourhood":"s/n",
	"address":"s/n"
	},
"img":{
	"url":"https://www.nexojornal.com.br/incoming/imagens/Sala_de_aula_itapevi/BINARY/Sala_de_aula_itapevi",
	"alt":"C. C. Professor Walter Carlos de Magalhães Fraenkel",
	"title":"C. C. Professor Walter Carlos de Magalhães Fraenkel",
	}
},

];

export default data;
