let data = [

{
"id":"1",
"name":"Teatro dos Quatro",
"description":{
	"short_text":"O Teatro dos Quatro 35 um dos quatro teatros do Shopping da Ga5vea, inaugurado em 1978.Confira a programaxef;fao:",
	"text":"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
	},
"contactData":"",
"characteristics":{
	"price":"$$",
	"lgbt": ""
	},
"geoResult":{
	"point":{
		"lat":"-22.975266",
		"lng":"-43.227725"
		},
	"neighbourhood":"Rua Maruques de São Vicente, 52/2",
	"address":"Gavea"
	},
"img":{
	"url":"http://andreafiorini.com.br/wp-content/uploads/2015/04/Teatro4_web7.jpg",
	"alt":"Teatro dos quatro",
	"title":"Teatro dos quatro",
	}
},
{
"id":"2",
"name":"Gilson Martins",
"description":{
	"short_text":"Criador de bolsas com a bandeira do Brasil, o designer Gilson Martins revolucionou a teecnica com sofisticaxef;eeo. Al60m de inovar com pex73as procuzidas em material reciclado, sua produxef;e0o 29 inspirada nas belezas do Rio.",
	"text":"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
	},
"contactData":"",
"characteristics":{
	"price":"$$",
	"lgbt": ""
	},
"geoResult":{
	"point":{
		"lat":"-22.98399",
		"lng":"-43.208888"
		},
	"neighbourhood":"Rua Visconde de Pirajá, 462",
	"address":"Ipanema"
	},
"img":{
	"url":"http://site.gilsonmartins.com.br/news/img/SemanaDesignRio/A%20Design%20Party,%20na%20loja%20Gilson%20Martins%20Ipanema,%20homenageou%20o%20design%20carioca..JPG",
	"alt":"Gilson Martins",
	"title":"Gilson Martins",
	}
},
{
"id":"3",
"name":"Parque dos Patins - Lagoa",
"description":{
	"short_text":"O Parque dos Patins é um parque localizado no bairro da Lagoa, na cidade do Rio de Janeiro, no Brasil",
	"text":"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
	},
"contactData":"",
"characteristics":{
	"price":"$$",
	"lgbt": ""
	},
"geoResult":{
	"point":{
		"lat":"-22.98399",
		"lng":"-43.208888"
		},
	"neighbourhood":"Av. Borges de Medeiros, s/n",
	"address":"Lagoa"
	},
"img":{
	"url":"https://catracalivre.com.br/wp-content/uploads/2013/01/Parque_dos_Patins_-_divulgacao.jpg",
	"alt":"Parque dos Patins",
	"title":"Parque dos Patins",
	}
},

{
"id":"4",
"name":"Galeria Laura Alvim",
"description":{
	"short_text":"Individual do artista paulistano, radicado no Rio apresenta quatro instala}65?es de grandes dimens?es.",
	"text":"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
	},
"contactData":"",
"characteristics":{
	"price":"$$",
	"lgbt": ""
	},
"geoResult":{
	"point":{
		"lat":"-22.986802",
		"lng":"-43.196225"
		},
	"neighbourhood":"Av. Vieira Souto, 176",
	"address":"Ipanema"
	},
"img":{
	"url":"http://www.artrio.art.br/sites/default/files/laura3.jpg",
	"alt":"Galeria Laura Alvim",
	"title":"Galeria Laura Alvim",
	}
},
];

export default data;
