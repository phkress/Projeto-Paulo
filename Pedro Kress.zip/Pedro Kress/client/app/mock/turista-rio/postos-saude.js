let data = [

{
"id":"1",
"name":"SMS RIO PADI PEDRO II",
"description":{
	"short_text":"UPA",
	"text":"UPA"
	},
"contactData":"",
"characteristics":{
	"price":"$$",
	"lgbt": ""
	},
"geoResult":{
	"point":{
		"lat":"-22.912115",
		"lng":"-43.687183"
		},
	"neighbourhood":"RUA DO PRADO, 325",
	"address":"SANTA CRUZ"
	},
"img":{
	"url":"http://www.rio.rj.gov.br/igstatic/47/80/55/4780550.jpg",
	"alt":"UPA",
	"title":"UPA",
	}
},
{
"id":"2",
"name":"SMS CF NÉLIO DE OLIVEIRA",
"description":{
	"short_text":"UPA",
	"text":"UPA"
	},
"contactData":"",
"characteristics":{
	"price":"$$",
	"lgbt": ""
	},
"geoResult":{
	"point":{
		"lat":"-22.897056",
		"lng":"-43.195688"
		},
	"neighbourhood":"S/N",
	"address":"RUA DA GAMBÔA"
	},
"img":{
	"url":"http://www.portomaravilha.com.br/uploads/teste55c91a761ac2e.jpg",
	"alt":"SMS CF NÉLIO DE OLIVEIRA",
	"title":"SMS CF NÉLIO DE OLIVEIRA",
	}
},
];

export default data;
